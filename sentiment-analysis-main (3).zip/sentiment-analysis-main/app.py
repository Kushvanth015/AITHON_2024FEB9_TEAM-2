from flask import Flask, render_template, request
from werkzeug.utils import secure_filename
import os
import re
import nltk

# Download VADER lexicon
nltk.download('vader_lexicon')

from nltk.tokenize import sent_tokenize
from nltk.corpus import stopwords
from nltk.sentiment.vader import SentimentIntensityAnalyzer

app = Flask(__name__)

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Function to clean the text
def clean_text(text):
    # Remove timestamps, names, media messages, and URLs
    cleaned_text = re.sub(r'\d{2}/\d{2}/\d{4}, \d{2}:\d{2} - .*?: ', '', text)  # Remove timestamps and names
    cleaned_text = re.sub(r'\d+/\d+/\d+, \d+:\d+ (AM|PM) - ', '', cleaned_text)  # Remove another timestamp format
    cleaned_text = re.sub(r'<Media omitted>', '', cleaned_text)  # Remove media messages
    cleaned_text = re.sub(r'http\S+|www.\S+', '', cleaned_text)  # Remove URLs
    return cleaned_text

# Function to perform sentiment analysis
def analyze_sentiment(text):
    sia = SentimentIntensityAnalyzer()
    scores = sia.polarity_scores(text)
    compound_score = scores['compound']
    if compound_score >= 0.05:
        return 'Positive', compound_score
    elif compound_score <= -0.05:
        return 'Negative', compound_score
    else:
        return 'Neutral', compound_score

# Check if the uploaded file has an allowed extension
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        if 'file' not in request.files:
            return render_template('index.html', error='No file part')

        file = request.files['file']

        if file.filename == '':
            return render_template('index.html', error='No selected file')

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            with open(file_path, 'r', encoding='utf-8') as f:
                chat_text = f.read()

            cleaned_text = clean_text(chat_text)

            # Tokenize the text into sentences
            sentences = sent_tokenize(cleaned_text)

            # Remove stop words from each sentence
            stop_words = set(stopwords.words('english'))
            filtered_sentences = []
            for sentence in sentences:
                words = sentence.split()
                filtered_words = [word for word in words if word.lower() not in stop_words and word.isalnum()]
                filtered_sentences.append(' '.join(filtered_words))

            # Analyze sentiment for each sentence
            sentiment_results = []
            total_sentences = len(filtered_sentences)
            for sentence in filtered_sentences:
                if sentence.strip():
                    sentiment, compound_score = analyze_sentiment(sentence)
                    sentiment_results.append((sentence, sentiment, compound_score))

            # Calculate percentage of each sentiment category
            sentiment_counts = {'Positive': 0, 'Negative': 0, 'Neutral': 0}
            for _, sentiment, _ in sentiment_results:
                sentiment_counts[sentiment] += 1

            sentiment_percentages = {}
            for sentiment, count in sentiment_counts.items():
                sentiment_percentages[sentiment] = count / total_sentences * 100 if total_sentences > 0 else 0

            return render_template('index.html', sentiment_results=sentiment_results, sentiment_percentages=sentiment_percentages)

        else:
            return render_template('index.html', error='File type not allowed')

    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
